<?php

namespace Mknooihuisen\LaravelFusionauth;

class LaravelFusionauth
{
    // Build your next great package.
}
